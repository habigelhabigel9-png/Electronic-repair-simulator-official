# Electronics Repair Simulator: PWA + Firebase setup

Files: index.html (the game), manifest.webmanifest, sw.js, icons/, firebase-config.js, firebase-sync.js, firebase.json, firestore.rules, .firebaserc

## Run it
PWA install and offline mode need https or localhost (not file://). Test locally with `npx serve .`

## Turn on cloud save
1. Firebase console: create a project, add a Web app, copy its config into firebase-config.js.
2. Authentication > Sign-in method: enable Google.
3. Firestore Database: create one, then deploy firestore.rules.
4. Put your project id in .firebaserc, then run `firebase deploy`.
Players stay on local saves until they tap Upload in Settings > Cloud save.

## Updating
Change `VERSION` in sw.js (for example ers-v2) whenever you edit the game so installed copies refresh.
