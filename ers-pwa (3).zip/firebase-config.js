// Paste your Firebase web app config here (Firebase console > Project settings > Your apps).
// While apiKey is empty, cloud save stays switched off and the game runs fully offline.
window.ERS_FIREBASE_CONFIG = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: ""
};
