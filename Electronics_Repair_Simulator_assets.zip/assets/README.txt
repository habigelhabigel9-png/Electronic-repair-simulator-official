Electronics Repair Simulator - Part 2 visual assets
All files are hand-built vector illustrations (SVG, transparent backgrounds, consistent top-left lighting).
No photographs were used. The game file embeds these same illustrations, so the game works fully offline.

components/   58 files: 29 component types, each with a normal and a -damaged version (80x80, pads at the lower corners)
boards/       7 board themes: smartphone motherboard, laptop motherboard, power bank board, speaker/amplifier board,
              LED driver board, USB charging board, generic board (with the matching connector)
tools/        13 tool icons: precision screwdriver, precision tweezers, multimeter, soldering iron, magnifier, ESD brush,
              jumper wires, desoldering pump, bench power supply, USB tester, battery tester, thermal camera, oscilloscope
instruments/  6 front panels: bench power supply, soldering station, oscilloscope, digital multimeter, USB tester, battery tester
              (in the game these show live values)
devices/      8 device exteriors: LED flashlight, Bluetooth speaker, portable radio, power bank, USB phone charger,
              smartphone, laptop, PC motherboard
hero/         menu illustration
