/* Electronics Repair Simulator: visual layer.
   Wraps the existing renderers (R.*, shell, ws, paint). It never touches game state,
   saves, Firebase or the mechanics. All imagery is in ./assets (see assets/README.txt). */
(function(){'use strict';
const AS='assets/',IM=(n,c)=>`<img class="${c||''}" src="${AS}${n}" alt="" decoding="async" draggable="false">`;
const SCN={levels:'scene-levels.svg',career:'scene-career.svg',inventory:'scene-inventory.svg',shop:'scene-shop.svg',skills:'scene-skills.svg',history:'scene-history.svg',settings:'scene-settings.svg',tutorial:'scene-tutorial.svg',learn:'scene-courses.svg',profile:'scene-profile.svg',safety:'scene-safety.svg',result:'scene-result.svg'};
const SUB={levels:'Pick a job off the board. Harder faults sit further down.',career:'Your rank, your next job and how far you have come.',inventory:'Parts you own, sorted into bins.',shop:'Buy the exact parts a repair needs.',skills:'Spend skill points on better tools and cheaper parts.',history:'Every bench job, signed off in the logbook.',settings:'Sound, hints, backups and cloud save.',tutorial:'The routine, the meter, the iron and staying safe.',learn:'Short lessons, a knowledge check, then a real repair.',profile:'Your technician ID, stats and unlocked tools.',safety:'Habits that keep you and the equipment safe.',result:'Test report and payout.'};
/* line icons that replace emoji */
const ICO={'📚':'<path d="M5 4h10a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3zM5 17a3 3 0 0 1 3-3h10M9 8h5"/>','👤':'<circle cx="12" cy="8" r="4"/><path d="M4 21c1-5 4-7 8-7s7 2 8 7"/>','🦺':'<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6zM9 12l2 2 4-4"/>','🏆':'<path d="M8 4h8v5a4 4 0 0 1-8 0zM8 6H4c0 3 1 4 4 4M16 6h4c0 3-1 4-4 4M12 13v4M8 21h8M9 17h6"/>','❓':'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 .9-1 1.7M12 17h.01"/>'};
const RE=/(📚|👤|🦺|🏆|❓)\uFE0F?/;
function emo(root){if(!root)return;const w=document.createTreeWalker(root,NodeFilter.SHOW_TEXT),hit=[];let n;while((n=w.nextNode()))if(RE.test(n.nodeValue))hit.push(n);
 hit.forEach(t=>{const f=document.createDocumentFragment();t.nodeValue.split(new RegExp(RE.source,'g')).forEach(p=>{if(ICO[p]){const s=document.createElement('span');s.innerHTML=`<svg class="i" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICO[p]}</svg>`;f.appendChild(s.firstChild)}else if(p)f.appendChild(document.createTextNode(p))});t.replaceWith(f)})}
/* section scene headers */
{const s0=shell;shell=function(){let h=s0();const s=UI.screen;h=h.replace('<div class="shell">',`<div class="shell" data-s="${s}">`);if(s=='job'||s=='workshop')return h;
 let img=SCN[s],sub=SUB[s]||'';if(s=='lesson'){const l=UI.les||[0,0];img=`scene-lesson-${Math.min(6,l[0]*2+l[1]+1)}.svg`;sub=(CRS[l[0]]||{t:''}).t}
 if(!img)return h;if(s=='lesson'){const l=UI.les||[0,0],q=CRS[l[0]]&&CRS[l[0]].ls[l[1]];h=h.replace(/<h2>Lesson<\/h2>/,'<h2>'+(q?q.t:'Lesson')+'</h2>')}
 return h.replace(/<h2>([^<]*)<\/h2>/,(m,t)=>`<header class="scene">${IM(img)}<div class="st"><h2>${t}</h2><p>${sub}</p></div></header>`)}}
/* home */
{const m0=R.menu;R.menu=function(){return`<div class="home">${m0().replace(/<svg class="hero"[\s\S]*?<\/svg>(<h1 class="wm">[\s\S]*?<\/h1>)/,(m,t)=>`<div class="hw">${IM('scene-home.svg','herob')}${t}</div>`)}</div>`}}
/* empty bench */
{const w0=ws;ws=function(){return w0().replace(/<svg class="hero"[\s\S]*?<\/svg>/,IM('scene-empty.svg','herob'))}}
/* courses: lesson art on every course and lesson row */
{const l0=R.learn;R.learn=function(){let i=0;return l0().replace(/<div class="card crs l(\d)">/g,(m,l)=>m+IM('scene-lesson-'+(+l*2+1)+'.svg','cth')).replace(/<button class="(les[^"]*)"([^>]*)>/g,(m,c,a)=>{i++;return`<button class="${c}"${a}>${IM('scene-lesson-'+Math.min(6,i)+'.svg','lth')}`})}}
/* skills: tool art and rank pips */
{const k0=R.skills,A0={'Sharp Eyes':'prop-lens.svg','Datasheet Library':'prop-dmm.svg','Haggler':'prop-spool.svg','Reputation':'prop-tweezers.svg'};
 R.skills=function(){return k0().replace(/<div class="card"><b>([^<]+)<\/b> <span class="mu">rank (\d+)\/(\d+)<\/span>/g,(m,n,a,b)=>`<div class="card">${A0[n]?IM(A0[n],'sk'):''}<b>${n}<span class="pips" role="img" aria-label="rank ${a} of ${b}">${Array.from({length:+b},(_,j)=>`<i class="${j<+a?'on':''}"></i>`).join('')}</span></b>`)}}
/* settings: real toggle switches */
{const s0=R.settings,sw=(a,l,on)=>`<button class="sw${on?' on':''}" data-act="${a}" role="switch" aria-checked="${on}"><span>${l}</span><i></i></button>`;
 R.settings=function(){return s0().replace(/<button data-act="snd">Sound: (on|off)<\/button>/,(m,v)=>sw('snd','Sound',v=='on')).replace(/<button data-act="hint">Hints: (on|off)<\/button>/,(m,v)=>sw('hint','Hints',v=='on'))}}
/* workbench: replace the flat mat with the rendered desk, real tools and a live meter */
function deskify(){const d=document.querySelector('.desk');if(!d)return;const st=d.querySelector('.stage');if(!st||st.querySelector('.dbg'))return;
 const o=st.querySelector('svg.props');if(o)o.remove();
 const L=(n,x,y,w,h)=>`<img class="dbg" src="${AS}${n}" alt="" style="left:${x}px;top:${y}px;width:${w}px;height:${h}px" draggable="false">`;
 const T=(k,n,x,y,w,h,lab,r)=>{const lk=(k=='scope'||k=='therm')&&typeof unl=='function'&&!unl(k);return`<button class="pp${UI.tool==k?' on':''}${lk?' lk':''}" data-act="tool" data-a="${k}" aria-label="${lab}" title="${lab}" style="left:${x}px;top:${y}px;width:${w}px;height:${h}px;--r:${r||0}deg"><img src="${AS}${n}" alt="" draggable="false"></button>`};
 let lcd='0.00';try{const r=mmRead();if(r&&r.t)lcd=r.t}catch(e){}
 st.insertAdjacentHTML('afterbegin',L('bench-desk.svg',0,0,1200,820)+L('prop-leads.svg',0,0,1200,820)+
  T('mm','prop-dmm.svg',80,170,230,360,'Multimeter')+`<div class="dlcd" style="left:135px;top:224px;width:120px;height:66px">${lcd}</div>`+
  T('scope','prop-scope.svg',845,96,262,165,'Oscilloscope')+T('mag','prop-lens.svg',900,282,170,170,'Magnifier')+T('iron','prop-iron.svg',770,585,400,115,'Soldering iron',-6)+
  L('prop-spool.svg',900,455,190,124)+T('twz','prop-tweezers.svg',800,722,300,56,'Tweezers',-3)+T('scr','prop-driver.svg',510,716,280,66,'Screwdriver',-3)+T('psu','prop-psu.svg',150,44,200,94,'Bench supply'))}
/* device cradle: anti-static foam pad instead of a dark placeholder panel */
{const e0=ext;ext=function(){return e0().replace(/<rect width="360" height="250" fill="url\(#mat\)"\/>/,'<rect width="360" height="250" rx="12" fill="#0e1214"/><rect x="5" y="5" width="350" height="240" rx="9" fill="#1a2024" stroke="#2f3a40" stroke-width="2"/>').replace(/<path d="M0 50H360M0 100H360[^>]*\/>/,'')}}
{const p0=paint;paint=function(an){p0(an);try{emo(document.getElementById('app'));deskify()}catch(e){console.warn('visuals',e)}}}
window.ERS_VIS=1;})();
